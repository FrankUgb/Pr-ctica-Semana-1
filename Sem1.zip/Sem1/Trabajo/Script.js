const carousel = document.getElementById('carousel');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
let currentIndex = 0;

nextBtn.addEventListener('click', () => {
    showImage(currentIndex + 1);
});

prevBtn.addEventListener('click', () => {
    showImage(currentIndex - 1);
});

function showImage(index) {
    const totalImages = document.querySelectorAll('.carousel-item').length;

    if (index >= totalImages) {
        currentIndex = 0;
    } else if (index < 0) {
        currentIndex = totalImages - 1;
    } else {
        currentIndex = index;
    }

    const translateValue = -currentIndex * 100 + '%';
    carousel.style.transform = 'translateX(' + translateValue + ')';
}
