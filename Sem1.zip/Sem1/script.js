function funcion(){
    alert("Hola has hecho click en el boton")
}